from django.db import models
from django.dispatch import receiver 
from django.db.models.signals import post_save 

class Silo0(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)
    
    def __str__(self):
        return str(self.Temp)

class Silo1(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)
    
    def __str__(self):
        return str(self.Temp)

class Silo2(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)

    def __str__(self):
        return str(self.Temp)

class Silo3(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)

    def __str__(self):
        return str(self.Temp)

class Silo5(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)
    
    def __str__(self):
        return str(self.Temp)

class Silo6(models.Model):
    X= models.DecimalField(decimal_places=15, max_digits=25)
    Y = models.DecimalField(decimal_places=15, max_digits=25)
    Temp = models.DecimalField(decimal_places=15, max_digits=25)
    
    def __str__(self):
        return str(self.Temp)

# Create your models here.


from django.shortcuts import render, redirect
from django.http import HttpResponse,HttpResponseRedirect, response
from .models import Silo0, Silo1, Silo2, Silo3, Silo5, Silo6
from pathlib import Path
import sqlite3
import io

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import urllib, base64






# Create your views here.


def main(response):
    
    Path('my_data.db').touch()
    conn = sqlite3.connect('my_data.db')
    c = conn.cursor()
    
    def Silo0():
        
        x0=c.execute('''select x FROM Silo0''').fetchall()
        y0 = c.execute('''select y FROM Silo0''').fetchall()
        z0=  c.execute('''select temperature FROM Silo0''').fetchall()
        plt.plot(x0,y0,z0)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        plt.grid(True)
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='png')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri0 = urllib.parse.quote(string)    
        
        return uri0


    def Silo1():

        x1=c.execute('''select x FROM Silo1''').fetchall()
        y1 = c.execute('''select y FROM Silo1''').fetchall() 
        z1=  c.execute('''select temperature FROM Silo1''').fetchall()
        plt.plot(x1,y1,z1)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='png')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri1 = urllib.parse.quote(string)    
        
        return uri1

    def Silo2():
        x2=c.execute('''select x FROM Silo2''').fetchall()
        y2 = c.execute('''select y FROM Silo2''').fetchall()
        z2=  c.execute('''select temperature FROM Silo2''').fetchall()
        plt.plot(x2,y2,z2)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='png')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri2 = urllib.parse.quote(string)    
        
        return uri2

    def Silo3():
        x3=c.execute('''select x FROM Silo3''').fetchall()
        y3 = c.execute('''select y FROM Silo3''').fetchall()
        z3=  c.execute('''select temperature FROM Silo3''').fetchall()
        plt.plot(x3,y3,z3)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='png')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri3 = urllib.parse.quote(string)    
        
        return uri3
    

    def Silo5():
        x5=c.execute('''select x FROM Silo5''').fetchall()
        y5 = c.execute('''select y FROM Silo5''').fetchall()
        z5=  c.execute('''select temperature FROM Silo5''').fetchall()
        plt.plot(x5,y5,z5)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='png')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri5 = urllib.parse.quote(string)    
        
        return uri5

    
    
    def Silo6():
        x=c.execute('''select x FROM Silo6''').fetchall()
        y = c.execute('''select y FROM Silo6''').fetchall()
        z=  c.execute('''select temperature FROM Silo6''').fetchall()
        plt.plot(x,y,z)
        plt.xlabel("Silos coordinates")
        plt.ylabel("temperature( C)")
        fig = plt.gcf()
        plt.close()
        buf=io.BytesIO()
        
        fig.savefig(buf, format='JPEG')

        
        buf.seek(0)   
        
        
        string= base64.b64encode(buf.read())
        uri = urllib.parse.quote(string)    
        
        return uri
  
    

    
    return render(response,"food/base.html", {'data0':Silo0(), 'data1':Silo1(),'data2':Silo2(),'data3':Silo3(),'data5':Silo5(),'data6':Silo6() })

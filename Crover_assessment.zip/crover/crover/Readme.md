To run this Project please do as following:-

    1) please install following python libraries:-
        a) matplotlib
        b) sqlite3
    2) extract and open folder name crover
    3) After the above step open the terminal and type python manage.py runserver
    4) go to the generated url in the terminal
    5) In the generated Url you will see the 6 generated graphs.

Due to some incidents I wasn't able to start the project in given time, I made this Project in 2 hours.

About:-
   I generated the graphs using MatplotLib, then encoded them into images and then passed it as a variable and then rendered it in HTml page.
Due to conversion into image it is not in high pixels initially i was planning to use a different library like Chart.js but it would have  taken more time. I hope you can still consider me for an interview.

